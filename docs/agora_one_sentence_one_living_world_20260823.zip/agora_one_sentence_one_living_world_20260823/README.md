# Agora: One Sentence, One Living World

This release contains the latest 14-page paper and its 11 figures in both PDF
and PNG formats.

## Contents

- `agora_one_sentence_one_living_world.pdf`: compiled paper
- `agora_one_sentence_one_living_world.tex`: self-contained paper source
- `figures/`: publication figures in vector PDF and raster PNG formats

## Build

Run XeLaTeX twice from this directory:

```bash
xelatex -interaction=nonstopmode -halt-on-error agora_one_sentence_one_living_world.tex
xelatex -interaction=nonstopmode -halt-on-error agora_one_sentence_one_living_world.tex
```
